jQuery(document).ready(function( $ ) {

  $('#view_more_desc').trigger( "click" )

  $('#listing_details').trigger( "click" )

});
